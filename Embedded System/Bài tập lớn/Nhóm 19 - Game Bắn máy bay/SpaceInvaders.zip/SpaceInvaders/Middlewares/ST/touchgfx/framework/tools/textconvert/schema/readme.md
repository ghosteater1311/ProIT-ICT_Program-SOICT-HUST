# Touchgfx text database
## texts.xml
 - An example of a touchgfx text database
## texts.xsd
 - The XML schema used for validating the texts.xml

The texts.xml has a reference to the texts.xsd, so when opening the texts.xml in an XML
editor (e.g. visual studio) your texts.xml will be validated according to the texts.xsd.
